# 🎉 Sistema de Gestión de Eventos - SPA

## 📋 Información del Proyecto

**Nombre:** Sistema de Gestión de Eventos  
**Tipo:** Single Page Application (SPA)  
**Tecnologías:** JavaScript ES6+, Vite, JSON Server  
**Autor:** [Tu Nombre Completo]  
**Cohorte:** [Tu Cohorte]  
**Fecha:** Febrero 2026

---

## 🎯 Descripción del Sistema

Sistema web completo para la gestión y registro de eventos, desarrollado como Single Page Application (SPA) que permite a los usuarios autenticarse con diferentes roles (admin y visitante), gestionar eventos, y realizar registros con validación de capacidad máxima.

### Características Principales

✅ **Autenticación y Registro de Usuarios**
- Sistema de login con validación de credenciales
- Registro de nuevos usuarios con roles (admin/visitante)
- Persistencia de sesión mediante LocalStorage
- Protección de rutas según rol del usuario

✅ **Gestión de Eventos (Admin)**
- Crear nuevos eventos con todos los detalles
- Editar eventos existentes
- Eliminar eventos
- Visualizar todos los registros por evento
- Actualizar estados de eventos

✅ **Visualización y Registro (Visitante)**
- Ver listado completo de eventos disponibles
- Filtrar eventos por categoría
- Registrarse en eventos con capacidad disponible
- Cancelar registros propios
- Ver historial de registros

✅ **Validaciones y Manejo de Errores**
- Validación de campos vacíos en formularios
- Verificación de capacidad máxima antes de registrarse
- Prevención de registros duplicados
- Mensajes descriptivos de error
- Try-catch en todas las operaciones asíncronas

---

## 🏗️ Arquitectura del Proyecto

### Estructura de Carpetas

```
event-management-spa/
│
├── index.html                 # HTML principal
├── vite.config.js            # Configuración de Vite
├── package.json              # Dependencias y scripts
├── db.json                   # Base de datos JSON Server
│
├── src/
│   ├── main.js              # Entry point de la aplicación
│   │
│   ├── components/          # Componentes de la UI
│   │   ├── Auth.js         # Login y Registro
│   │   ├── EventList.js    # Lista de eventos
│   │   ├── EventForm.js    # Formulario de eventos
│   │   ├── EventDetail.js  # Detalle de evento
│   │   └── UserProfile.js  # Perfil de usuario
│   │
│   ├── services/           # Servicios de API
│   │   └── api.js         # Comunicación con JSON Server
│   │
│   ├── utils/              # Utilidades
│   │   ├── state.js       # State management + LocalStorage
│   │   ├── router.js      # SPA Router con protección
│   │   └── helpers.js     # Validaciones y utilidades
│   │
│   └── styles/             # Estilos CSS
│       └── main.css       # Estilos principales
│
└── README.md               # Este archivo
```

### Entidades Principales

#### 1. Usuario (User)
```javascript
{
  id: number,
  name: string,
  email: string,
  password: string,
  role: "admin" | "visitante",
  createdAt: string (ISO 8601)
}
```

#### 2. Evento (Event)
```javascript
{
  id: number,
  title: string,
  description: string,
  date: string (YYYY-MM-DD),
  time: string (HH:MM),
  location: string,
  category: string,
  maxCapacity: number,
  currentRegistrations: number,
  organizerId: number,
  organizerName: string,
  status: "active" | "full" | "cancelled" | "completed",
  createdAt: string (ISO 8601)
}
```

#### 3. Registro (Registration)
```javascript
{
  id: number,
  eventId: number,
  userId: number,
  userName: string,
  registeredAt: string (ISO 8601)
}
```

---

## 🚀 Instalación y Ejecución

### Prerrequisitos

- Node.js versión 18 o superior
- npm (incluido con Node.js)
- Navegador web moderno (Chrome, Firefox, Edge)

### Paso 1: Instalación de Dependencias

```bash
# Navegar a la carpeta del proyecto
cd event-management-spa

# Instalar dependencias
npm install
```

Esto instalará:
- `vite` - Dev server y build tool
- `json-server` - Backend REST API simulado
- `concurrently` - Para ejecutar múltiples comandos

### Paso 2: Iniciar la Aplicación

```bash
npm run dev
```

Este comando inicia simultáneamente:
- **Vite Dev Server** en `http://localhost:5173`
- **JSON Server** en `http://localhost:3001`

La aplicación se abrirá automáticamente en tu navegador.

### Comandos Disponibles

```bash
# Desarrollo (Frontend + Backend)
npm run dev

# Solo Frontend (Vite)
npm run client

# Solo Backend (JSON Server)
npm run server

# Build para producción
npm run build

# Preview del build
npm run preview
```

---

## 👥 Usuarios de Prueba

### Administrador
- **Email:** admin@eventos.com
- **Contraseña:** admin123
- **Permisos:**
  - Crear, editar y eliminar eventos
  - Ver todos los registros
  - Acceso al panel de administración

### Visitante
- **Email:** visitante@eventos.com
- **Contraseña:** visitante123
- **Permisos:**
  - Ver eventos disponibles
  - Registrarse en eventos
  - Ver su historial de registros

---

## 🔄 Diagrama de Flujo de Autenticación

```
┌─────────────┐
│   Inicio    │
│  (Login)    │
└──────┬──────┘
       │
       ▼
┌─────────────────┐
│ Validar         │
│ Credenciales    │
└────┬───────┬────┘
     │       │
  ✓  │       │  ✗
     │       │
     ▼       ▼
┌─────────┐  ┌────────────┐
│  Admin? │  │   Error    │
└─┬─────┬─┘  │  Mensaje   │
  │     │    └────────────┘
✓ │     │ ✗
  │     │
  ▼     ▼
┌──────────┐  ┌─────────────┐
│  Panel   │  │   Panel     │
│  Admin   │  │  Visitante  │
└──────────┘  └─────────────┘
```

---

## 🗺️ Rutas de la Aplicación

### Rutas Públicas
- `/` - Login y Registro

### Rutas Protegidas (Requiere Autenticación)

#### Para Visitantes:
- `/events` - Lista de eventos
- `/events/:id` - Detalle de evento
- `/my-registrations` - Mis registros
- `/profile` - Perfil de usuario

#### Para Administradores:
- `/admin/events` - Gestión de eventos
- `/admin/events/new` - Crear evento
- `/admin/events/:id/edit` - Editar evento
- `/admin/registrations` - Ver todos los registros

---

## 🔧 Funcionalidades Implementadas

### Parte 1 - Análisis de Requisitos ✅

- [x] Identificación de entidades (Usuario, Evento, Registro)
- [x] Diseño de flujo de autenticación con roles
- [x] Diagrama de rutas de la SPA
- [x] Estructura base modular

### Parte 2 - Modelado y Persistencia ✅

- [x] Archivo `db.json` con estructura completa
- [x] Configuración de `json-server`
- [x] Endpoints CRUD funcionales
- [x] LocalStorage para persistencia de sesión
- [x] State management centralizado

### Parte 3 - Implementación de Funcionalidades ✅

- [x] Registro de usuarios con validación
- [x] Login con verificación de credenciales
- [x] Protección de rutas según rol
- [x] Redirecciones automáticas
- [x] CRUD completo de eventos (Admin)
- [x] Visualización de eventos (Visitante)
- [x] Sistema de registro a eventos
- [x] Validación de capacidad máxima
- [x] Prevención de registros duplicados

### Parte 4 - Manejo de Errores y Validaciones ✅

- [x] Try-catch en todas las operaciones Fetch
- [x] Validación de campos vacíos
- [x] Validación de formato de email
- [x] Validación de contraseñas (mínimo 6 caracteres)
- [x] Verificación de capacidad antes de registro
- [x] Mensajes descriptivos de error
- [x] Notificaciones visuales de éxito/error
- [x] Validación en tiempo real de formularios

### Parte 5 - Documentación ✅

- [x] README.md profesional y completo
- [x] Instrucciones claras de instalación
- [x] Descripción detallada del sistema
- [x] Diagramas de flujo
- [x] Capturas de pantalla (ver sección siguiente)
- [x] Documentación de código con comentarios

---

## 📸 Capturas de Pantalla

### 1. Pantalla de Login
![Login](./screenshots/login.png)
*Pantalla de autenticación con opciones de login y registro*

### 2. Panel de Visitante
![Eventos](./screenshots/events-visitor.png)
*Vista de eventos disponibles para visitantes*

### 3. Panel de Administrador
![Admin](./screenshots/admin-events.png)
*Panel de administración de eventos*

### 4. Formulario de Creación de Evento
![Crear Evento](./screenshots/create-event.png)
*Formulario con validaciones para crear eventos*

---

## 🎓 Conceptos Técnicos Aplicados

### 1. Manipulación Avanzada del DOM

```javascript
// Renderizado dinámico de componentes
function renderEventList(events) {
    const container = document.getElementById('events-container');
    container.innerHTML = events.map(event => `
        <div class="event-card" data-id="${event.id}">
            <h3>${event.title}</h3>
            <p>${event.description}</p>
        </div>
    `).join('');
}
```

### 2. Persistencia con LocalStorage

```javascript
// Guardar sesión del usuario
stateManager.setCurrentUser(user);
localStorage.setItem('event_manager_currentUser', JSON.stringify(user));

// Recuperar sesión al recargar
const savedUser = JSON.parse(localStorage.getItem('event_manager_currentUser'));
```

### 3. Consumo de APIs con Fetch

```javascript
// Operación con manejo de errores
async function login(email, password) {
    try {
        const response = await fetch(`${API_URL}/users?email=${email}`);
        if (!response.ok) throw new Error('Error en la petición');
        const users = await response.json();
        return users[0];
    } catch (error) {
        throw new Error('No se pudo conectar con el servidor');
    }
}
```

### 4. Rutas Dinámicas en SPA

```javascript
// Router con protección de rutas
router.register('/admin/events', renderAdminView, {
    requiresAuth: true,
    allowedRoles: ['admin']
});

// Navegación programática
router.navigate('/events');
```

### 5. Autenticación y Roles

```javascript
// Verificación de permisos
function canAccessRoute(path) {
    const user = stateManager.getCurrentUser();
    if (!user) return false;
    return allowedRoles.includes(user.role);
}
```

### 6. Validaciones

```javascript
// Validación de email
function validateEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}

// Validación de capacidad
function validateCapacity(current, max) {
    if (current >= max) {
        throw new Error('Evento lleno');
    }
}
```

---

## 🔒 Seguridad Implementada

- ✅ Validación de inputs en cliente y servidor
- ✅ Protección contra inyección XSS
- ✅ Rutas protegidas por autenticación
- ✅ Verificación de roles antes de operaciones
- ✅ Sanitización de datos antes de almacenar
- ✅ Manejo seguro de sesiones

---

## 📊 Endpoints de la API (JSON Server)

### Usuarios

```
GET    /users                    # Listar todos
GET    /users?email=X            # Buscar por email
GET    /users/:id                # Obtener por ID
POST   /users                    # Crear usuario
PATCH  /users/:id                # Actualizar usuario
DELETE /users/:id                # Eliminar usuario
```

### Eventos

```
GET    /events                   # Listar todos
GET    /events?category=X        # Filtrar por categoría
GET    /events?status=X          # Filtrar por estado
GET    /events/:id               # Obtener por ID
POST   /events                   # Crear evento (admin)
PATCH  /events/:id               # Actualizar evento (admin)
DELETE /events/:id               # Eliminar evento (admin)
```

### Registros

```
GET    /registrations            # Listar todos
GET    /registrations?userId=X   # Por usuario
GET    /registrations?eventId=X  # Por evento
POST   /registrations            # Crear registro
DELETE /registrations/:id        # Cancelar registro
```

---

## 🧪 Testing Manual

### Casos de Prueba Implementados

#### 1. Autenticación
- [x] Login con credenciales correctas
- [x] Login con credenciales incorrectas
- [x] Registro de nuevo usuario
- [x] Validación de email duplicado
- [x] Persistencia de sesión después de recargar

#### 2. Gestión de Eventos (Admin)
- [x] Crear evento con todos los campos
- [x] Validación de campos vacíos
- [x] Editar evento existente
- [x] Eliminar evento
- [x] Ver lista completa de eventos

#### 3. Registro a Eventos (Visitante)
- [x] Ver eventos disponibles
- [x] Registrarse en evento con capacidad
- [x] Bloqueo al intentar registro en evento lleno
- [x] Prevención de registro duplicado
- [x] Cancelar registro propio

#### 4. Validaciones
- [x] Email inválido muestra error
- [x] Contraseña corta muestra error
- [x] Fecha pasada no permite crear evento
- [x] Capacidad negativa muestra error
- [x] Campos vacíos resaltados en rojo

---

## 🐛 Solución de Problemas

### JSON Server no inicia

```bash
# Verificar puerto 3001 libre
netstat -an | find "3001"

# Iniciar en otro puerto
json-server --watch db.json --port 3002
```

### Vite no inicia

```bash
# Limpiar cache
rm -rf node_modules package-lock.json
npm install
```

### Error de CORS

JSON Server ya incluye CORS habilitado. Si persiste:
1. Verifica que ambos servidores estén corriendo
2. Revisa la consola del navegador para errores específicos

### Sesión no persiste

1. Verifica que LocalStorage esté habilitado
2. Abre DevTools → Application → Local Storage
3. Revisa que exista `event_manager_currentUser`

---

## 📈 Mejoras Futuras

- [ ] Autenticación con JWT
- [ ] Backend real con Express/NestJS
- [ ] Base de datos PostgreSQL
- [ ] Envío de emails de confirmación
- [ ] Sistema de notificaciones en tiempo real
- [ ] Upload de imágenes para eventos
- [ ] Integración con calendario
- [ ] Exportar eventos a PDF
- [ ] Sistema de calificaciones
- [ ] Chat en vivo para eventos

---

## 📝 Buenas Prácticas Aplicadas

✅ **Código Modular** - Separación clara de responsabilidades  
✅ **ES6+ Modules** - Importaciones/exportaciones  
✅ **Async/Await** - Manejo moderno de promesas  
✅ **Error Handling** - Try-catch en operaciones críticas  
✅ **Validaciones** - Cliente y servidor  
✅ **Comentarios** - Documentación en código  
✅ **Naming Conventions** - Nombres descriptivos  
✅ **DRY Principle** - No repetir código  
✅ **SOLID Principles** - Responsabilidad única  

---

## 🤝 Sustentación Técnica

### Decisiones de Diseño

**¿Por qué Vite?**
- Build time ultrarrápido
- Hot Module Replacement instantáneo
- Configuración mínima
- Soporte nativo de ES modules

**¿Por qué JSON Server?**
- Setup inmediato sin configuración
- REST API completa automática
- Perfecto para prototipos y aprendizaje
- Fácil transición a backend real

**¿Por qué LocalStorage?**
- Persistencia simple del lado del cliente
- No requiere configuración de servidor
- Apropiado para datos de sesión
- Fácil de implementar y debuggear

**¿Por qué SPA?**
- Experiencia de usuario fluida
- No recargas de página
- Estado centralizado
- Mejor rendimiento percibido

### Arquitectura Elegida

**Patrón de Estado Centralizado**
- Un solo punto de verdad para el estado
- Fácil debugging
- Predecible y mantenible

**Separación de Responsabilidades**
- Components: UI y eventos
- Services: Lógica de negocio y API
- Utils: Funciones auxiliares
- Styles: Presentación visual

---

## 👨‍💻 Información del Desarrollador

**Nombre:** [Tu Nombre Completo]  
**Cohorte:** [Tu Cohorte]  
**Email:** [tu.email@ejemplo.com]  
**GitHub:** [tu-usuario]  
**Fecha de Entrega:** Febrero 2026

---

## 📄 Licencia

Este proyecto fue desarrollado como parte de una prueba técnica educativa.

---

**¡Gracias por revisar este proyecto! 🎉**

Para cualquier pregunta o aclaración, no dudes en contactarme.
