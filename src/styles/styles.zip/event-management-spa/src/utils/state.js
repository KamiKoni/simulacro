// State Management - Estado Global con persistencia en LocalStorage

class StateManager {
    constructor() {
        this.state = {
            currentUser: this.loadFromLocalStorage('currentUser'),
            currentView: 'login',
            currentFilter: 'all',
            currentCategory: 'all',
            isAuthenticated: false
        };
        
        this.listeners = [];
        
        // Verificar autenticación al iniciar
        if (this.state.currentUser) {
            this.state.isAuthenticated = true;
        }
    }

    // ==========================================
    // GESTIÓN DE ESTADO
    // ==========================================

    /**
     * Obtener estado actual
     */
    getState() {
        return { ...this.state };
    }

    /**
     * Actualizar estado y notificar listeners
     */
    setState(newState) {
        this.state = { ...this.state, ...newState };
        this.notify();
    }

    /**
     * Suscribirse a cambios de estado
     */
    subscribe(listener) {
        this.listeners.push(listener);
        // Retornar función para cancelar suscripción
        return () => {
            this.listeners = this.listeners.filter(l => l !== listener);
        };
    }

    /**
     * Notificar a todos los suscriptores
     */
    notify() {
        this.listeners.forEach(listener => listener(this.state));
    }

    // ==========================================
    // PERSISTENCIA EN LOCALSTORAGE
    // ==========================================

    /**
     * Guardar en LocalStorage
     */
    saveToLocalStorage(key, value) {
        try {
            localStorage.setItem(`event_manager_${key}`, JSON.stringify(value));
        } catch (error) {
            console.error('Error al guardar en LocalStorage:', error);
        }
    }

    /**
     * Cargar desde LocalStorage
     */
    loadFromLocalStorage(key) {
        try {
            const data = localStorage.getItem(`event_manager_${key}`);
            return data ? JSON.parse(data) : null;
        } catch (error) {
            console.error('Error al cargar desde LocalStorage:', error);
            return null;
        }
    }

    /**
     * Eliminar de LocalStorage
     */
    removeFromLocalStorage(key) {
        try {
            localStorage.removeItem(`event_manager_${key}`);
        } catch (error) {
            console.error('Error al eliminar de LocalStorage:', error);
        }
    }

    /**
     * Limpiar todo el LocalStorage de la app
     */
    clearLocalStorage() {
        try {
            const keys = Object.keys(localStorage);
            keys.forEach(key => {
                if (key.startsWith('event_manager_')) {
                    localStorage.removeItem(key);
                }
            });
        } catch (error) {
            console.error('Error al limpiar LocalStorage:', error);
        }
    }

    // ==========================================
    // MÉTODOS DE AUTENTICACIÓN
    // ==========================================

    /**
     * Establecer usuario actual y persistir sesión
     */
    setCurrentUser(user) {
        this.setState({ 
            currentUser: user,
            isAuthenticated: !!user
        });
        
        if (user) {
            this.saveToLocalStorage('currentUser', user);
            this.saveToLocalStorage('sessionStart', new Date().toISOString());
        } else {
            this.removeFromLocalStorage('currentUser');
            this.removeFromLocalStorage('sessionStart');
        }
    }

    /**
     * Cerrar sesión
     */
    logout() {
        this.setCurrentUser(null);
        this.clearLocalStorage();
        this.setState({ 
            currentView: 'login',
            isAuthenticated: false
        });
    }

    /**
     * Verificar si el usuario está autenticado
     */
    isUserAuthenticated() {
        return this.state.isAuthenticated && this.state.currentUser !== null;
    }

    /**
     * Verificar si el usuario es admin
     */
    isAdmin() {
        return this.state.currentUser?.role === 'admin';
    }

    /**
     * Verificar si el usuario es visitante
     */
    isVisitor() {
        return this.state.currentUser?.role === 'visitante';
    }

    /**
     * Obtener información del usuario actual
     */
    getCurrentUser() {
        return this.state.currentUser;
    }

    // ==========================================
    // MÉTODOS DE NAVEGACIÓN
    // ==========================================

    /**
     * Cambiar vista actual
     */
    setView(view) {
        this.setState({ currentView: view });
    }

    /**
     * Establecer filtro actual
     */
    setFilter(filter) {
        this.setState({ currentFilter: filter });
    }

    /**
     * Establecer categoría actual
     */
    setCategory(category) {
        this.setState({ currentCategory: category });
    }

    // ==========================================
    // UTILIDADES
    // ==========================================

    /**
     * Obtener tiempo de sesión
     */
    getSessionDuration() {
        const sessionStart = this.loadFromLocalStorage('sessionStart');
        if (!sessionStart) return 0;
        
        const start = new Date(sessionStart);
        const now = new Date();
        return Math.floor((now - start) / 1000 / 60); // en minutos
    }

    /**
     * Verificar y validar sesión
     */
    validateSession() {
        const user = this.loadFromLocalStorage('currentUser');
        const sessionStart = this.loadFromLocalStorage('sessionStart');
        
        if (!user || !sessionStart) {
            this.logout();
            return false;
        }

        // Opcional: Implementar expiración de sesión (ej: 24 horas)
        const sessionDuration = this.getSessionDuration();
        const MAX_SESSION_MINUTES = 24 * 60; // 24 horas
        
        if (sessionDuration > MAX_SESSION_MINUTES) {
            console.log('Sesión expirada');
            this.logout();
            return false;
        }

        return true;
    }

    /**
     * Guardar preferencias del usuario
     */
    saveUserPreferences(preferences) {
        this.saveToLocalStorage('userPreferences', preferences);
    }

    /**
     * Cargar preferencias del usuario
     */
    loadUserPreferences() {
        return this.loadFromLocalStorage('userPreferences') || {
            theme: 'light',
            notifications: true
        };
    }
}

// Exportar instancia única (Singleton)
export const stateManager = new StateManager();

// Validar sesión al cargar la aplicación
if (stateManager.isUserAuthenticated()) {
    stateManager.validateSession();
}
