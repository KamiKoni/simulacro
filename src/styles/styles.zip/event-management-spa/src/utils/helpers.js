// Utilidades y Validaciones

// ==========================================
// FORMATEO DE DATOS
// ==========================================

export function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-ES', { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric'
    });
}

export function formatDateTime(dateString) {
    const date = new Date(dateString);
    return date.toLocaleString('es-ES', { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

export function formatTime(timeString) {
    const [hours, minutes] = timeString.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const hour12 = hour % 12 || 12;
    return `${hour12}:${minutes} ${ampm}`;
}

// ==========================================
// VALIDACIONES
// ==========================================

/**
 * Validar email
 */
export function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

/**
 * Validar contraseña
 */
export function validatePassword(password) {
    const errors = [];
    
    if (password.length < 6) {
        errors.push('La contraseña debe tener al menos 6 caracteres');
    }
    
    if (!/[A-Za-z]/.test(password)) {
        errors.push('La contraseña debe contener al menos una letra');
    }
    
    if (!/[0-9]/.test(password)) {
        errors.push('La contraseña debe contener al menos un número');
    }
    
    return {
        isValid: errors.length === 0,
        errors
    };
}

/**
 * Validar campos requeridos
 */
export function validateRequired(fields) {
    const errors = {};
    
    Object.entries(fields).forEach(([key, value]) => {
        if (!value || (typeof value === 'string' && value.trim() === '')) {
            errors[key] = `El campo ${key} es requerido`;
        }
    });
    
    return {
        isValid: Object.keys(errors).length === 0,
        errors
    };
}

/**
 * Validar fecha (no puede ser en el pasado)
 */
export function validateFutureDate(dateString) {
    const selectedDate = new Date(dateString);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    return selectedDate >= today;
}

/**
 * Validar capacidad máxima
 */
export function validateCapacity(capacity) {
    const num = parseInt(capacity);
    
    if (isNaN(num)) {
        return { isValid: false, error: 'La capacidad debe ser un número' };
    }
    
    if (num <= 0) {
        return { isValid: false, error: 'La capacidad debe ser mayor a 0' };
    }
    
    if (num > 10000) {
        return { isValid: false, error: 'La capacidad no puede exceder 10,000 personas' };
    }
    
    return { isValid: true };
}

/**
 * Validar que los registros actuales no excedan la capacidad
 */
export function validateRegistrationCapacity(currentRegistrations, maxCapacity, newRegistrations = 1) {
    const total = currentRegistrations + newRegistrations;
    
    if (total > maxCapacity) {
        return {
            isValid: false,
            error: `No hay suficiente capacidad. Disponible: ${maxCapacity - currentRegistrations}, Solicitado: ${newRegistrations}`
        };
    }
    
    return { isValid: true };
}

// ==========================================
// NOTIFICACIONES
// ==========================================

/**
 * Mostrar notificación
 */
export function showNotification(message, type = 'info', duration = 3000) {
    // Crear elemento de notificación
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    
    // Icono según el tipo
    const icons = {
        success: '✓',
        error: '✗',
        warning: '⚠',
        info: 'ℹ'
    };
    
    notification.innerHTML = `
        <span class="notification-icon">${icons[type] || icons.info}</span>
        <span class="notification-message">${message}</span>
    `;
    
    // Agregar al DOM
    document.body.appendChild(notification);
    
    // Mostrar con animación
    setTimeout(() => notification.classList.add('show'), 10);
    
    // Ocultar y eliminar
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => notification.remove(), 300);
    }, duration);
}

/**
 * Mostrar modal de confirmación
 */
export function showConfirmModal(message, onConfirm, onCancel) {
    const modal = document.createElement('div');
    modal.className = 'confirm-modal active';
    modal.innerHTML = `
        <div class="confirm-modal-content">
            <div class="confirm-modal-header">
                <h3>Confirmación</h3>
            </div>
            <div class="confirm-modal-body">
                <p>${message}</p>
            </div>
            <div class="confirm-modal-footer">
                <button class="btn btn-secondary" id="confirm-cancel">Cancelar</button>
                <button class="btn btn-primary" id="confirm-ok">Aceptar</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Event listeners
    document.getElementById('confirm-ok').addEventListener('click', () => {
        modal.remove();
        if (onConfirm) onConfirm();
    });
    
    document.getElementById('confirm-cancel').addEventListener('click', () => {
        modal.remove();
        if (onCancel) onCancel();
    });
    
    // Cerrar al hacer click fuera
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.remove();
            if (onCancel) onCancel();
        }
    });
}

// ==========================================
// MANIPULACIÓN DOM
// ==========================================

/**
 * Crear elemento HTML
 */
export function createElement(tag, className = '', innerHTML = '') {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (innerHTML) element.innerHTML = innerHTML;
    return element;
}

/**
 * Limpiar contenido de un elemento
 */
export function clearElement(element) {
    while (element.firstChild) {
        element.removeChild(element.firstChild);
    }
}

/**
 * Mostrar/Ocultar elemento
 */
export function toggleElement(element, show) {
    if (show) {
        element.classList.remove('hidden');
    } else {
        element.classList.add('hidden');
    }
}

// ==========================================
// UTILIDADES GENERALES
// ==========================================

/**
 * Debounce function
 */
export function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * Throttle function
 */
export function throttle(func, limit) {
    let inThrottle;
    return function(...args) {
        if (!inThrottle) {
            func.apply(this, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

/**
 * Capitalizar primera letra
 */
export function capitalize(str) {
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
}

/**
 * Truncar texto
 */
export function truncate(str, length = 100) {
    if (str.length <= length) return str;
    return str.slice(0, length) + '...';
}

/**
 * Escapar HTML para prevenir XSS
 */
export function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

/**
 * Obtener parámetros de URL
 */
export function getUrlParams() {
    const params = {};
    const searchParams = new URLSearchParams(window.location.search);
    
    for (const [key, value] of searchParams) {
        params[key] = value;
    }
    
    return params;
}

/**
 * Calcular porcentaje
 */
export function calculatePercentage(current, total) {
    if (total === 0) return 0;
    return Math.round((current / total) * 100);
}

/**
 * Obtener categorías únicas
 */
export function getUniqueCategories(items) {
    return [...new Set(items.map(item => item.category))];
}

/**
 * Ordenar array por fecha
 */
export function sortByDate(array, dateField = 'createdAt', ascending = false) {
    return [...array].sort((a, b) => {
        const dateA = new Date(a[dateField]);
        const dateB = new Date(b[dateField]);
        return ascending ? dateA - dateB : dateB - dateA;
    });
}

/**
 * Filtrar array por múltiples criterios
 */
export function filterByMultipleCriteria(array, filters) {
    return array.filter(item => {
        return Object.entries(filters).every(([key, value]) => {
            if (value === 'all' || value === '') return true;
            return item[key] === value;
        });
    });
}

/**
 * Generar ID único
 */
export function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

/**
 * Copiar al portapapeles
 */
export async function copyToClipboard(text) {
    try {
        await navigator.clipboard.writeText(text);
        showNotification('Copiado al portapapeles', 'success');
    } catch (err) {
        showNotification('Error al copiar', 'error');
    }
}

/**
 * Descargar como archivo
 */
export function downloadAsFile(content, filename, type = 'text/plain') {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
}
