// Router - Sistema de Rutas con Protección de Acceso

import { stateManager } from './state.js';

class Router {
    constructor() {
        this.routes = {};
        this.protectedRoutes = {};
        this.currentRoute = null;
        this.init();
    }

    /**
     * Inicializar router
     */
    init() {
        // Escuchar cambios en el historial del navegador
        window.addEventListener('popstate', () => {
            this.loadRoute(window.location.pathname);
        });

        // Prevenir navegación accidental
        window.addEventListener('beforeunload', (e) => {
            const state = stateManager.getState();
            if (state.isAuthenticated) {
                // Opcional: Advertir si hay cambios sin guardar
                // e.preventDefault();
                // e.returnValue = '';
            }
        });
    }

    /**
     * Registrar una ruta
     */
    register(path, handler, options = {}) {
        this.routes[path] = handler;
        
        // Registrar si la ruta requiere autenticación
        if (options.requiresAuth) {
            this.protectedRoutes[path] = {
                requiresAuth: true,
                allowedRoles: options.allowedRoles || []
            };
        }
    }

    /**
     * Verificar si el usuario tiene acceso a la ruta
     */
    canAccessRoute(path) {
        const protection = this.protectedRoutes[path];
        
        // Si la ruta no está protegida, permitir acceso
        if (!protection) return true;

        // Verificar autenticación
        if (protection.requiresAuth && !stateManager.isUserAuthenticated()) {
            return false;
        }

        // Verificar roles permitidos
        if (protection.allowedRoles.length > 0) {
            const currentUser = stateManager.getCurrentUser();
            if (!currentUser || !protection.allowedRoles.includes(currentUser.role)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Navegar a una ruta
     */
    navigate(path, data = {}) {
        // Verificar acceso
        if (!this.canAccessRoute(path)) {
            console.warn(`Acceso denegado a ${path}. Redirigiendo...`);
            this.handleUnauthorizedAccess(path);
            return;
        }

        // Actualizar historial del navegador
        window.history.pushState(data, '', path);
        
        // Cargar ruta
        this.loadRoute(path, data);
    }

    /**
     * Reemplazar ruta actual (sin agregar al historial)
     */
    replace(path, data = {}) {
        if (!this.canAccessRoute(path)) {
            this.handleUnauthorizedAccess(path);
            return;
        }

        window.history.replaceState(data, '', path);
        this.loadRoute(path, data);
    }

    /**
     * Cargar una ruta
     */
    loadRoute(path, data = {}) {
        const handler = this.routes[path] || this.routes['/404'] || this.routes['/'];
        
        if (handler) {
            this.currentRoute = path;
            handler(data);
        } else {
            console.error(`Ruta no encontrada: ${path}`);
            this.navigate('/');
        }
    }

    /**
     * Manejar acceso no autorizado
     */
    handleUnauthorizedAccess(attemptedPath) {
        const state = stateManager.getState();
        
        if (!state.isAuthenticated) {
            // Usuario no autenticado -> login
            this.replace('/');
            this.showMessage('Debes iniciar sesión para acceder a esta página', 'warning');
        } else {
            // Usuario autenticado pero sin permisos -> redirigir según rol
            const user = stateManager.getCurrentUser();
            
            if (user.role === 'admin') {
                this.replace('/admin/events');
            } else {
                this.replace('/events');
            }
            
            this.showMessage('No tienes permisos para acceder a esta página', 'error');
        }
    }

    /**
     * Mostrar mensaje al usuario
     */
    showMessage(message, type = 'info') {
        // Importar dinámicamente la función de notificación
        import('./helpers.js').then(({ showNotification }) => {
            showNotification(message, type);
        });
    }

    /**
     * Obtener ruta actual
     */
    getCurrentRoute() {
        return this.currentRoute;
    }

    /**
     * Volver atrás en el historial
     */
    goBack() {
        window.history.back();
    }

    /**
     * Ir adelante en el historial
     */
    goForward() {
        window.history.forward();
    }

    /**
     * Iniciar el router
     */
    start() {
        const initialPath = window.location.pathname;
        
        // Si no hay ruta o es la raíz, determinar ruta inicial
        if (initialPath === '/' || !this.routes[initialPath]) {
            const state = stateManager.getState();
            
            if (state.isAuthenticated) {
                const user = stateManager.getCurrentUser();
                const defaultPath = user.role === 'admin' ? '/admin/events' : '/events';
                this.replace(defaultPath);
            } else {
                this.loadRoute('/');
            }
        } else {
            this.loadRoute(initialPath);
        }
    }

    /**
     * Registrar ruta 404
     */
    register404(handler) {
        this.routes['/404'] = handler;
    }
}

// Exportar instancia única
export const router = new Router();

// Utilidades de navegación
export const navigationUtils = {
    /**
     * Navegar con confirmación
     */
    navigateWithConfirmation(path, message = '¿Estás seguro de que quieres salir?') {
        if (confirm(message)) {
            router.navigate(path);
        }
    },

    /**
     * Navegar después de un delay
     */
    navigateAfterDelay(path, delay = 1000) {
        setTimeout(() => {
            router.navigate(path);
        }, delay);
    },

    /**
     * Redireccionar según rol
     */
    redirectByRole() {
        const user = stateManager.getCurrentUser();
        
        if (!user) {
            router.navigate('/');
            return;
        }

        const path = user.role === 'admin' ? '/admin/events' : '/events';
        router.navigate(path);
    }
};
