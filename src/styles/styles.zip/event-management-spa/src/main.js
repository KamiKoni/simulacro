// Main Application Entry Point
import './styles/main.css';
import { router } from './utils/router.js';
import { stateManager } from './utils/state.js';
import { LoginComponent, initLoginHandlers } from './components/Auth.js';

// App Container
const app = document.getElementById('app');

// Register Routes
router.register('/', renderLogin);

router.register('/events', renderEventsView, {
    requiresAuth: true,
    allowedRoles: ['visitante', 'admin']
});

router.register('/admin/events', renderAdminView, {
    requiresAuth: true,
    allowedRoles: ['admin']
});

// Render Functions
function renderLogin() {
    const state = stateManager.getState();
    
    if (state.isAuthenticated) {
        const user = stateManager.getCurrentUser();
        const path = user.role === 'admin' ? '/admin/events' : '/events';
        router.navigate(path);
        return;
    }
    
    app.innerHTML = LoginComponent();
    initLoginHandlers();
}

async function renderEventsView() {
    app.innerHTML = '<div class="loading">Cargando eventos...</div>';
    // Implementar vista de eventos
}

async function renderAdminView() {
    app.innerHTML = '<div class="loading">Cargando panel admin...</div>';
    // Implementar vista admin
}

// Initialize
function init() {
    console.log('🎉 Sistema de Gestión de Eventos Iniciado');
    console.log('📡 JSON Server debe estar en http://localhost:3001');
    router.start();
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}
