// API Service - Comunicación con JSON Server
// Incluye manejo de errores con try-catch y validaciones

const API_URL = 'http://localhost:3001';

// ==========================================
// UTILIDAD PARA MANEJO DE ERRORES
// ==========================================

async function handleResponse(response) {
    if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
    }
    return await response.json();
}

async function fetchWithErrorHandling(url, options = {}) {
    try {
        const response = await fetch(url, options);
        return await handleResponse(response);
    } catch (error) {
        console.error('Error en la petición:', error);
        throw new Error(`No se pudo conectar con el servidor. Verifica que JSON Server esté corriendo en ${API_URL}`);
    }
}

// ==========================================
// USUARIOS
// ==========================================

export const userService = {
    /**
     * Autenticación de usuario
     * @param {string} email 
     * @param {string} password 
     * @returns {Promise<Object|null>}
     */
    async login(email, password) {
        // Validación de campos vacíos
        if (!email || !password) {
            throw new Error('Email y contraseña son requeridos');
        }

        try {
            const users = await fetchWithErrorHandling(`${API_URL}/users?email=${email}&password=${password}`);
            
            if (users.length === 0) {
                throw new Error('Credenciales incorrectas. Por favor verifica tu email y contraseña.');
            }
            
            return users[0];
        } catch (error) {
            throw error;
        }
    },

    /**
     * Registro de nuevo usuario
     * @param {Object} userData 
     * @returns {Promise<Object>}
     */
    async register(userData) {
        // Validaciones
        if (!userData.name || !userData.email || !userData.password) {
            throw new Error('Todos los campos son requeridos');
        }

        if (userData.password.length < 6) {
            throw new Error('La contraseña debe tener al menos 6 caracteres');
        }

        // Verificar si el email ya existe
        try {
            const existingUsers = await fetchWithErrorHandling(`${API_URL}/users?email=${userData.email}`);
            
            if (existingUsers.length > 0) {
                throw new Error('Este email ya está registrado');
            }

            // Crear usuario
            const newUser = {
                ...userData,
                role: userData.role || 'visitante',
                createdAt: new Date().toISOString()
            };

            return await fetchWithErrorHandling(`${API_URL}/users`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newUser)
            });
        } catch (error) {
            throw error;
        }
    },

    /**
     * Obtener todos los usuarios (solo admin)
     */
    async getAll() {
        try {
            return await fetchWithErrorHandling(`${API_URL}/users`);
        } catch (error) {
            throw new Error('Error al obtener usuarios');
        }
    },

    /**
     * Obtener usuario por ID
     */
    async getById(id) {
        try {
            return await fetchWithErrorHandling(`${API_URL}/users/${id}`);
        } catch (error) {
            throw new Error('Usuario no encontrado');
        }
    }
};

// ==========================================
// EVENTOS
// ==========================================

export const eventService = {
    /**
     * Obtener todos los eventos
     */
    async getAll() {
        try {
            return await fetchWithErrorHandling(`${API_URL}/events`);
        } catch (error) {
            throw new Error('Error al cargar eventos');
        }
    },

    /**
     * Obtener evento por ID
     */
    async getById(id) {
        try {
            return await fetchWithErrorHandling(`${API_URL}/events/${id}`);
        } catch (error) {
            throw new Error('Evento no encontrado');
        }
    },

    /**
     * Filtrar eventos por categoría
     */
    async getByCategory(category) {
        try {
            return await fetchWithErrorHandling(`${API_URL}/events?category=${category}`);
        } catch (error) {
            throw new Error('Error al filtrar eventos');
        }
    },

    /**
     * Filtrar eventos por estado
     */
    async getByStatus(status) {
        try {
            return await fetchWithErrorHandling(`${API_URL}/events?status=${status}`);
        } catch (error) {
            throw new Error('Error al filtrar eventos');
        }
    },

    /**
     * Crear nuevo evento (solo admin)
     */
    async create(eventData) {
        // Validaciones
        if (!eventData.title || !eventData.description || !eventData.date || 
            !eventData.time || !eventData.location || !eventData.category) {
            throw new Error('Todos los campos son obligatorios');
        }

        if (!eventData.maxCapacity || eventData.maxCapacity <= 0) {
            throw new Error('La capacidad máxima debe ser mayor a 0');
        }

        try {
            const newEvent = {
                ...eventData,
                currentRegistrations: 0,
                status: 'active',
                createdAt: new Date().toISOString()
            };

            return await fetchWithErrorHandling(`${API_URL}/events`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newEvent)
            });
        } catch (error) {
            throw new Error('Error al crear evento');
        }
    },

    /**
     * Actualizar evento (solo admin)
     */
    async update(id, eventData) {
        // Validación de capacidad
        if (eventData.maxCapacity && eventData.maxCapacity <= 0) {
            throw new Error('La capacidad máxima debe ser mayor a 0');
        }

        try {
            return await fetchWithErrorHandling(`${API_URL}/events/${id}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(eventData)
            });
        } catch (error) {
            throw new Error('Error al actualizar evento');
        }
    },

    /**
     * Eliminar evento (solo admin)
     */
    async delete(id) {
        try {
            return await fetchWithErrorHandling(`${API_URL}/events/${id}`, {
                method: 'DELETE'
            });
        } catch (error) {
            throw new Error('Error al eliminar evento');
        }
    },

    /**
     * Actualizar estado del evento
     */
    async updateStatus(id, status) {
        const validStatuses = ['active', 'full', 'cancelled', 'completed'];
        
        if (!validStatuses.includes(status)) {
            throw new Error('Estado no válido');
        }

        try {
            return await this.update(id, { status });
        } catch (error) {
            throw error;
        }
    }
};

// ==========================================
// REGISTROS A EVENTOS
// ==========================================

export const registrationService = {
    /**
     * Obtener todos los registros
     */
    async getAll() {
        try {
            return await fetchWithErrorHandling(`${API_URL}/registrations`);
        } catch (error) {
            throw new Error('Error al cargar registros');
        }
    },

    /**
     * Registrar usuario a un evento
     */
    async register(eventId, userId, userName) {
        try {
            // Verificar si el evento existe y tiene capacidad
            const event = await eventService.getById(eventId);
            
            // Validar capacidad máxima
            if (event.currentRegistrations >= event.maxCapacity) {
                throw new Error('El evento ha alcanzado su capacidad máxima');
            }

            // Verificar si el usuario ya está registrado
            const existingRegistrations = await fetchWithErrorHandling(
                `${API_URL}/registrations?eventId=${eventId}&userId=${userId}`
            );

            if (existingRegistrations.length > 0) {
                throw new Error('Ya estás registrado en este evento');
            }

            // Crear registro
            const registration = {
                eventId,
                userId,
                userName,
                registeredAt: new Date().toISOString()
            };

            const newRegistration = await fetchWithErrorHandling(`${API_URL}/registrations`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(registration)
            });

            // Actualizar contador de registros del evento
            await eventService.update(eventId, {
                currentRegistrations: event.currentRegistrations + 1,
                status: (event.currentRegistrations + 1) >= event.maxCapacity ? 'full' : 'active'
            });

            return newRegistration;
        } catch (error) {
            throw error;
        }
    },

    /**
     * Cancelar registro
     */
    async cancel(registrationId, eventId) {
        try {
            // Obtener el evento
            const event = await eventService.getById(eventId);

            // Eliminar registro
            await fetchWithErrorHandling(`${API_URL}/registrations/${registrationId}`, {
                method: 'DELETE'
            });

            // Actualizar contador de registros del evento
            const newCount = Math.max(0, event.currentRegistrations - 1);
            await eventService.update(eventId, {
                currentRegistrations: newCount,
                status: newCount < event.maxCapacity ? 'active' : 'full'
            });

            return { success: true };
        } catch (error) {
            throw new Error('Error al cancelar registro');
        }
    },

    /**
     * Obtener registros por usuario
     */
    async getByUserId(userId) {
        try {
            return await fetchWithErrorHandling(`${API_URL}/registrations?userId=${userId}`);
        } catch (error) {
            throw new Error('Error al cargar tus registros');
        }
    },

    /**
     * Obtener registros por evento
     */
    async getByEventId(eventId) {
        try {
            return await fetchWithErrorHandling(`${API_URL}/registrations?eventId=${eventId}`);
        } catch (error) {
            throw new Error('Error al cargar registros del evento');
        }
    }
};
