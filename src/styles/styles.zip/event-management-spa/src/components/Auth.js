// Login and Register Component
import { userService } from '../services/api.js';
import { stateManager } from '../utils/state.js';
import { router } from '../utils/router.js';
import { showNotification, validateEmail, validatePassword } from '../utils/helpers.js';

export function LoginComponent() {
    return `
        <div class="auth-container">
            <div class="auth-card">
                <div class="auth-header">
                    <h1>🎉 Sistema de Gestión de Eventos</h1>
                    <p class="subtitle">Administra y participa en eventos increíbles</p>
                </div>

                <!-- Tabs -->
                <div class="auth-tabs">
                    <button class="auth-tab active" data-tab="login">Iniciar Sesión</button>
                    <button class="auth-tab" data-tab="register">Registrarse</button>
                </div>

                <!-- Login Form -->
                <form id="login-form" class="auth-form active">
                    <div class="form-group">
                        <label for="login-email">
                            <span class="label-icon">📧</span>
                            Email
                        </label>
                        <input 
                            type="email" 
                            id="login-email" 
                            required 
                            placeholder="tu@email.com"
                            autocomplete="email"
                        >
                        <span class="form-error" id="login-email-error"></span>
                    </div>
                    
                    <div class="form-group">
                        <label for="login-password">
                            <span class="label-icon">🔒</span>
                            Contraseña
                        </label>
                        <input 
                            type="password" 
                            id="login-password" 
                            required 
                            placeholder="••••••••"
                            autocomplete="current-password"
                        >
                        <span class="form-error" id="login-password-error"></span>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block">
                        Iniciar Sesión
                    </button>
                </form>

                <!-- Register Form -->
                <form id="register-form" class="auth-form">
                    <div class="form-group">
                        <label for="register-name">
                            <span class="label-icon">👤</span>
                            Nombre Completo
                        </label>
                        <input 
                            type="text" 
                            id="register-name" 
                            required 
                            placeholder="Juan Pérez"
                            autocomplete="name"
                        >
                        <span class="form-error" id="register-name-error"></span>
                    </div>

                    <div class="form-group">
                        <label for="register-email">
                            <span class="label-icon">📧</span>
                            Email
                        </label>
                        <input 
                            type="email" 
                            id="register-email" 
                            required 
                            placeholder="tu@email.com"
                            autocomplete="email"
                        >
                        <span class="form-error" id="register-email-error"></span>
                    </div>

                    <div class="form-group">
                        <label for="register-password">
                            <span class="label-icon">🔒</span>
                            Contraseña
                        </label>
                        <input 
                            type="password" 
                            id="register-password" 
                            required 
                            placeholder="••••••••"
                            autocomplete="new-password"
                        >
                        <span class="form-error" id="register-password-error"></span>
                        <small class="form-hint">Mínimo 6 caracteres, incluye letras y números</small>
                    </div>

                    <div class="form-group">
                        <label for="register-role">
                            <span class="label-icon">🎭</span>
                            Rol
                        </label>
                        <select id="register-role" required>
                            <option value="visitante">Visitante</option>
                            <option value="admin">Administrador</option>
                        </select>
                        <span class="form-error" id="register-role-error"></span>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block">
                        Crear Cuenta
                    </button>
                </form>

                <!-- Demo Users -->
                <div class="demo-users">
                    <p>🚀 Acceso rápido con usuarios de prueba:</p>
                    <div class="demo-grid">
                        <button class="btn-demo" data-email="admin@eventos.com" data-password="admin123">
                            👨‍💼 Admin
                        </button>
                        <button class="btn-demo" data-email="visitante@eventos.com" data-password="visitante123">
                            👤 Visitante
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
}

export function initLoginHandlers() {
    // Tab switching
    const tabs = document.querySelectorAll('.auth-tab');
    const forms = document.querySelectorAll('.auth-form');

    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const targetTab = tab.dataset.tab;
            
            // Update active tab
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            
            // Update active form
            forms.forEach(f => f.classList.remove('active'));
            document.getElementById(`${targetTab}-form`).classList.add('active');
            
            // Clear errors
            clearAllErrors();
        });
    });

    // Login form handler
    const loginForm = document.getElementById('login-form');
    loginForm?.addEventListener('submit', handleLogin);

    // Register form handler
    const registerForm = document.getElementById('register-form');
    registerForm?.addEventListener('submit', handleRegister);

    // Demo users
    const demoBtns = document.querySelectorAll('.btn-demo');
    demoBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            document.getElementById('login-email').value = btn.dataset.email;
            document.getElementById('login-password').value = btn.dataset.password;
            
            // Switch to login tab
            document.querySelector('.auth-tab[data-tab="login"]').click();
            
            // Auto submit after short delay
            setTimeout(() => loginForm.dispatchEvent(new Event('submit')), 100);
        });
    });

    // Real-time validation
    setupRealTimeValidation();
}

async function handleLogin(e) {
    e.preventDefault();
    
    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value;
    
    // Clear previous errors
    clearFormErrors('login');
    
    // Validate
    if (!validateLoginForm(email, password)) {
        return;
    }
    
    // Show loading state
    const submitBtn = e.target.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.disabled = true;
    submitBtn.textContent = 'Iniciando sesión...';
    
    try {
        const user = await userService.login(email, password);
        
        stateManager.setCurrentUser(user);
        showNotification(`¡Bienvenido ${user.name}! 👋`, 'success');
        
        // Redirect based on role
        setTimeout(() => {
            if (user.role === 'admin') {
                router.navigate('/admin/events');
            } else {
                router.navigate('/events');
            }
        }, 500);
        
    } catch (error) {
        showNotification(error.message, 'error');
        setFormError('login-email', 'Verifica tus credenciales');
    } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = originalText;
    }
}

async function handleRegister(e) {
    e.preventDefault();
    
    const name = document.getElementById('register-name').value.trim();
    const email = document.getElementById('register-email').value.trim();
    const password = document.getElementById('register-password').value;
    const role = document.getElementById('register-role').value;
    
    // Clear previous errors
    clearFormErrors('register');
    
    // Validate
    if (!validateRegisterForm(name, email, password)) {
        return;
    }
    
    // Show loading state
    const submitBtn = e.target.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.disabled = true;
    submitBtn.textContent = 'Creando cuenta...';
    
    try {
        const newUser = await userService.register({ name, email, password, role });
        
        showNotification('¡Cuenta creada exitosamente! 🎉', 'success');
        
        // Auto login
        stateManager.setCurrentUser(newUser);
        
        setTimeout(() => {
            if (newUser.role === 'admin') {
                router.navigate('/admin/events');
            } else {
                router.navigate('/events');
            }
        }, 500);
        
    } catch (error) {
        showNotification(error.message, 'error');
        if (error.message.includes('email')) {
            setFormError('register-email', error.message);
        }
    } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = originalText;
    }
}

function validateLoginForm(email, password) {
    let isValid = true;
    
    if (!email) {
        setFormError('login-email', 'El email es requerido');
        isValid = false;
    } else if (!validateEmail(email)) {
        setFormError('login-email', 'Email no válido');
        isValid = false;
    }
    
    if (!password) {
        setFormError('login-password', 'La contraseña es requerida');
        isValid = false;
    }
    
    return isValid;
}

function validateRegisterForm(name, email, password) {
    let isValid = true;
    
    if (!name || name.length < 3) {
        setFormError('register-name', 'El nombre debe tener al menos 3 caracteres');
        isValid = false;
    }
    
    if (!email) {
        setFormError('register-email', 'El email es requerido');
        isValid = false;
    } else if (!validateEmail(email)) {
        setFormError('register-email', 'Email no válido');
        isValid = false;
    }
    
    const passwordValidation = validatePassword(password);
    if (!passwordValidation.isValid) {
        setFormError('register-password', passwordValidation.errors[0]);
        isValid = false;
    }
    
    return isValid;
}

function setFormError(fieldId, message) {
    const errorElement = document.getElementById(`${fieldId}-error`);
    const inputElement = document.getElementById(fieldId);
    
    if (errorElement) {
        errorElement.textContent = message;
        errorElement.style.display = 'block';
    }
    
    if (inputElement) {
        inputElement.classList.add('error');
    }
}

function clearFormErrors(formPrefix) {
    const errors = document.querySelectorAll(`#${formPrefix}-form .form-error`);
    const inputs = document.querySelectorAll(`#${formPrefix}-form input`);
    
    errors.forEach(error => {
        error.textContent = '';
        error.style.display = 'none';
    });
    
    inputs.forEach(input => input.classList.remove('error'));
}

function clearAllErrors() {
    clearFormErrors('login');
    clearFormErrors('register');
}

function setupRealTimeValidation() {
    // Email validation
    const emailInputs = document.querySelectorAll('input[type="email"]');
    emailInputs.forEach(input => {
        input.addEventListener('blur', () => {
            const value = input.value.trim();
            const errorId = `${input.id}-error`;
            
            if (value && !validateEmail(value)) {
                setFormError(input.id, 'Email no válido');
            } else {
                document.getElementById(errorId).textContent = '';
                input.classList.remove('error');
            }
        });
    });
    
    // Clear error on focus
    const allInputs = document.querySelectorAll('.auth-form input');
    allInputs.forEach(input => {
        input.addEventListener('focus', () => {
            input.classList.remove('error');
            const errorId = `${input.id}-error`;
            const errorElement = document.getElementById(errorId);
            if (errorElement) {
                errorElement.textContent = '';
            }
        });
    });
}
